import json
import boto3
from botocore.exceptions import ClientError
from urllib.parse import urlparse
import os

s3_client = boto3.client('s3')
FAIL_STATUS = 'fail'

def lambda_handler(event, context):
    # This hanlder expects exactly 3 S3 URIs.
    # Each URI is for a YAML file that is defines the test configuration that is to be run

    # Check that there are 3 URIs
    config_file_a = event.get('config_file_a', None)
    config_file_b = event.get('config_file_b', None)
    config_file_c = event.get('config_file_c', None)
    if not config_file_a:
        return {
            'status': FAIL_STATUS,
            'description': 'Parameter config_file_a was not provided.'
        }
    if not config_file_b:
        return {
            'status': FAIL_STATUS,
            'description': 'Parameter config_file_b was not provided.'
        }
    if not config_file_c:
        return {
            'status': FAIL_STATUS,
            'description': 'Parameter config_file_c was not provided.'
        }
    
    s3_uris = [config_file_a, config_file_b, config_file_c] 

    # Check that each S3 URI has a .yaml extension
    for uri in s3_uris:
        key = urlparse(uri).path.lstrip('/')
        if not key.endswith('.yaml'):
            return {
                'status': FAIL_STATUS,
                'description': f'Each configuration file must be an S3 URI with a .yaml extension. There is an issue with {uri}'
            }
    
    result = {
        'status': 'success',
        'description': 'The configurations files are valid and accessible.',
        's3_uris': s3_uris
    }
    
    # Here we check that the S3 URIs are accessible
    # We might then read the files themselves and validate each of the fields set to acceptible values ... 

    for uri in s3_uris:
        try:
            parsed_uri = urlparse(uri)
            bucket_name = parsed_uri.netloc
            object_key = parsed_uri.path.lstrip('/')
            
            # Skip this test if the Dev-Test-Override environment variable is set
            if os.environ.get('Dev_Test_Override') is None:
                # check that the URI exists and is accessible
                s3_client.head_object(Bucket=bucket_name, Key=object_key)

        except ClientError as e:
            result['status'] = FAIL_STATUS
            result['description'] = f"Error accessing {uri}: {str(e)}"
            break
    
    return result
